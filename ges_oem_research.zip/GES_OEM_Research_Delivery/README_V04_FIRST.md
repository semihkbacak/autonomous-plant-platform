# GES v0.4 - güncel kaynak incelemesi

Bu paket önceki OEM araştırmasını, yeni Projects.zip kaynak incelemesiyle birleştirir. Projenin çalışan dosyaları ve testleri değiştirilmedi; HES/RES incelenmedi.

ÖNCE OKUYUN: 07_integration_recommendations/v04_code_review/GES_V04_CODE_REVIEW_REPORT.pdf. Önceki raporlardaki v0.4 modülleri mevcut değil/API eksik ifadeleri eski Drive sürümüne aittir; yeni arşivde bu modüller ve API/Dashboard dosyaları vardır. OEM araştırmasının kaynaklı parametreleri geçerliliğini korur. Eski GES_FINAL_TECHNICAL_REPORT.pdf eski kaynak görüntüsünün raporudur; bu ek rapor güncel mimari değerlendirmesinde önceliklidir.

232 GES testi geçti; tüm proje için 315 iddiası ayrıca doğrulanmadı. 7 günlük sentetik koşu tekrarlandı. 365 günlük ve gerçek saha/OEM doğrulaması yapılmadı. Manuel Dashboard kontrolü yapılmadı.

Kontrol scriptleri mevcut GES proje kökünü GES_PROJECT_ROOT ortam değişkeninden okur. Yeni inceleme çıktıları scriptin kendi klasörüne yazılır; proje klasörüne yazılmaz. probe.py içindeki eksik-MPPT deneyi bilerek hatalı kopya kayıt oluşturur; yeni SQLite çıktısı üretir. Üretim veritabanına yönlendirmeyin. Gereksinimler: projedeki GES bağımlılıkları, pytest, FastAPI/httpx; çalıştırılan sürümler execution_evidence.json içinde.

Mevcut OEM katsayılar bilinmeden gerçek tesis üretimi doğrulanmış sayılmaz. Parametre kataloğu öneri dosyasıdır, orijinal CSV üzerine uygulanmadı. Üretici orijinal PDFleri bu pakette kopyalanmadı; kaynak dizininde resmi URL/hash/sayfa kayıtları bulunur.
