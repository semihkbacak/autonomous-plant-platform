"""Reproduce rejected one-parameter PVWatts fits. Not an inverter application.
Inputs: published SMA AC-output load / efficiency table. No project mutations.
"""
from pathlib import Path
import argparse,csv,json
import numpy as np
from scipy.optimize import minimize_scalar

def main(samples,output):
 rows=list(csv.DictReader(Path(samples).open(encoding='utf-8-sig')));results=[]
 for voltage in [500,670,800]:
  group=[r for r in rows if r['component_id']=='SMA_STP50_40' and float(r['dc_voltage_v'])==voltage]
  x=np.array([float(r['output_load_fraction']) for r in group]);eta=np.array([float(r['efficiency_fraction']) for r in group])
  def prediction(nominal):
   zeta=x/eta*nominal
   return nominal/.9637*(-.0162*zeta-.0059/zeta+.9858)
  fit=minimize_scalar(lambda n:np.mean((prediction(n)-eta)**2),bounds=(.90,.999),method='bounded')
  error=(prediction(fit.x)-eta)*100
  results.append({'dc_voltage_v':voltage,'eta_nominal_diagnostic':float(fit.x),'rmse_percentage_points':float(np.sqrt(np.mean(error**2))),'max_error_percentage_points':float(np.max(np.abs(error))),'status':'REJECTED_FOR_OEM_USE','method':'diagnostic unconstrained scalar least-squares; no holdout; fixed PVWatts curve shape','source_document':'SMA WirkungDerat-TI-en-52 v5.2','page_number':102,'source_url':'https://files.sma.de/downloads/WirkungDerat-TI-en-52.pdf'})
 p=Path(output);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--samples',default=str(Path(__file__).resolve().parents[1]/'03_inverter_efficiency_thermal_pq/oem_efficiency_samples.csv'));a.add_argument('--output',default='build/efficiency_fit_diagnostics.json');n=a.parse_args();main(n.samples,n.output)
