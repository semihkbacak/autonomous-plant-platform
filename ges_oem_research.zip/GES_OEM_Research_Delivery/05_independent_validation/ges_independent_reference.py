"""Offline research checks only. Never edits APP sources/tests/databases.
Run python ges_independent_reference.py --output-dir build --source-root <GES snapshot>
OEM De Soto coefficients are deliberately NOT fabricated. Synthetic coefficients
exercise numerical equations; OEM panel power grid uses approximate PVWatts DC.
"""
from pathlib import Path
import argparse,json,csv,math,sys,hashlib
sys.dont_write_bytecode=True
import numpy as np
import pvlib
from scipy.optimize import brentq,minimize_scalar

def write_csv(p,rows):
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def desoto_coefficients(g,t,m):
 k=8.617333262145e-5;tk=t+273.15;tr=298.15
 il=g/1000*(m['IL']+m['alpha']*(t-25))
 eg=1.121*(1-.0002677*(tk-tr))
 i0=m['I0']*(tk/tr)**3*math.exp(1.121/(k*tr)-eg/(k*tk))
 return il,i0,m['Rs'],m['Rsh']*1000/g,m['a']*tk/tr

def independent_mpp(c):
 il,i0,rs,rsh,a=c
 def balance(v,i):return il-i0*math.expm1((v+i*rs)/a)-(v+i*rs)/rsh-i
 voc=brentq(lambda v:balance(v,0),0,100)
 def current(v):return brentq(lambda i:balance(v,i),0,il) if v<voc else 0.
 opt=minimize_scalar(lambda v:-v*current(v),bounds=(0,voc),method='bounded',options={'xatol':1e-11})
 return opt.x,current(opt.x),-opt.fun,voc

def main(output_dir,source_root=None):
 out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
 if source_root:
  sys.path.insert(0,str(Path(source_root).resolve()))
  from simulator.solar.pv_array import synthetic_demo_module,PVArrayConfiguration,calculate_pv_array_dc
  from simulator.solar.solar_temperature import calculate_pv_temperature
  from simulator.solar.inverter import InverterConfig,simulate_inverter
  from simulator.solar.ac_power_limits import ACOperatingRequest,evaluate_ac_power
 m={'alpha':.005,'IL':13.5,'I0':1e-10,'Rs':.30,'Rsh':400,'a':2}
 rows=[]
 for t in [15,25,45,65]:
  for g in [200,600,800,1000]:
   c=desoto_coefficients(g,t,m);v,i,p,voc=independent_mpp(c)
   ref=pvlib.pvsystem.singlediode(*pvlib.pvsystem.calcparams_desoto(g,t,alpha_sc=m['alpha'],a_ref=m['a'],I_L_ref=m['IL'],I_o_ref=m['I0'],R_sh_ref=m['Rsh'],R_s=m['Rs']))
   app=None
   if source_root:
    # Set ambient solely to make default Faiman cell temperature equal target.
    ta=t-g/(25+6.84)
    app=calculate_pv_array_dc(g,ta,1,PVArrayConfiguration(1,1,synthetic_demo_module())).module_pmp_w
   assert abs(p-ref['p_mp'])<1e-5
   if app is not None:assert abs(p-app)<1e-5
   rows.append(dict(G_Wm2=g,Tcell_C=t,independent_vmp_V=v,independent_imp_A=i,independent_pmp_W=p,pvlib_pmp_W=float(ref['p_mp']),app_pmp_W=app,absolute_difference_W=None if app is None else abs(app-p),value_type='synthetic_model_numerical_validation',source_url='https://doi.org/10.1016/j.solener.2005.06.010'))
 write_csv(out/'synthetic_desoto_independent_comparison.csv',rows)
 oem=[];fit=[]
 for cid,pstc,vmp,imp,voc,isc,alpha,beta,gamma in [('TRINA_TSM445_NEG9R28',445,44.3,10.05,52.6,10.71,.0004,-.0024,-.003),('JINKO_JKM585N72HL4V',585,42.52,13.76,51.16,14.55,.00045,-.0025,-.0029)]:
  try:
   params,opt=pvlib.ivtools.sdm.fit_desoto(vmp,imp,voc,isc,isc*alpha,voc*beta,72)
   fit.append(dict(component_id=cid,attempt='pvlib fit_desoto default initial guess',success=bool(opt.success),parameters=params,assumption='72 equivalent series cells used ONLY as initialization assumption, not OEM-confirmed; no integration'))
  except Exception as e:fit.append(dict(component_id=cid,attempt='pvlib fit_desoto default initial guess',success=False,error=str(e),assumption='72 equivalent series cells used ONLY as initialization assumption, not OEM-confirmed'))
  for t in [15,25,45,65]:
   for g in [200,600,800,1000]:oem.append(dict(component_id=cid,G_Wm2=g,Tcell_C=t,Pstc_W=pstc,gamma_1_K=gamma,pvwatts_dc_W=pstc*g/1000*(1+gamma*(t-25)),desoto_pmp_W=None,desoto_status='BLOCKED_NO_VERIFIED_COEFFICIENTS',value_type='approximate_model_using_oem_Pstc_gamma',source_id='D1' if cid.startswith('TRINA') else 'D2'))
 write_csv(out/'oem_panel_power_grid.csv',oem)
 (out/'desoto_fit_attempts.json').write_text(json.dumps(fit,indent=2))
 checks=[]
 def check(name,manual,actual,unit,source='L12',tol=1e-9):
  assert abs(manual-actual)<=tol
  checks.append(dict(test_id=name,reference_value=manual,compared_value=actual,absolute_difference=abs(manual-actual),unit=unit,tolerance=tol,source_id=source,status='PASS_NUMERICAL_NOT_FIELD_VALIDATION'))
 for g,ta,w in [(200,15,0),(600,25,1),(800,35,3),(1000,25,5),(0,25,1)]:
  manual=ta+g/(25+6.84*w);actual=calculate_pv_temperature(g,ta,w).module_temperature_c if source_root else float(pvlib.temperature.faiman(g,ta,w))
  check(f'FAIMAN_{g}_{w}',manual,actual,'degC','L10')
 for pdc in [0,.001,2,6,10,20]:
  eta=.96;pac0=10;pdc0=pac0/eta
  z=pdc/pdc0
  raw=0 if pdc==0 else max(0,eta/.9637*(-.0162*z-.0059/z+.9858)*pdc)
  manual=min(pac0,raw)
  actual=simulate_inverter(InverterConfig('SYNTHETIC',10,.96,200,800,1000,100),pdc,400).ac_available_kw if source_root else float(pvlib.inverter.pvwatts(pdc,pdc0,eta_inv_nom=eta))
  check(f'INVERTER_{pdc}',manual,actual,'kW')
 for q in [0,30,-30,50]:
  manual=math.sqrt(max(0,50**2-q**2));actual=evaluate_ac_power(ACOperatingRequest(50,50,q)).max_active_kw if source_root else manual
  check(f'PQ_50_{q}',manual,actual,'kW','D3')
 for p in [0,1,10,50]:check(f'ENERGY_15M_{p}',p*.25,p*15/60,'kWh','M2')
 # Independently solved two channels with different temperatures/irradiance.
 c1=independent_mpp(desoto_coefficients(1000,25,m));c2=independent_mpp(desoto_coefficients(600,45,m))
 check('MPPT_DC_POWER_SUM',c1[2]+c2[2],c1[0]*c1[1]+c2[0]*c2[1],'W','M1',1e-7)
 # Site-free synthetic geometry: isotropic POA reference is NOT Perez validation.
 for tilt,z,dni,dhi,ghi in [(0,30,800,100,792.820323027551),(30,30,800,100,792.820323027551),(90,60,600,120,420)]:
  incidence=math.cos(math.radians(z-tilt));beam=max(0,dni*incidence)
  sky=dhi*(1+math.cos(math.radians(tilt)))/2
  ground=ghi*.2*(1-math.cos(math.radians(tilt)))/2
  actual=pvlib.irradiance.get_total_irradiance(tilt,180,z,180,dni,ghi,dhi,albedo=.2,model='isotropic')['poa_global']
  check(f'POA_ISOTROPIC_GEOMETRY_{tilt}',beam+sky+ground,float(actual),'W/m2','L17',1e-7)
 check('DAILY_CONSTANT_10KW',10*24,sum([10*.25]*96),'kWh','M2')
 check('MONTH_JAN_CONSTANT_10KW',10*24*31,sum([240]*31),'kWh','M2')
 write_csv(out/'independent_scalar_checks.csv',checks)
 environment={'python':sys.version.split()[0],'pvlib':pvlib.__version__,'numpy':np.__version__,'source_comparison':'accessible older Drive GES source' if source_root else 'no APP source supplied','v04_315_tests':'NOT_EXECUTED_UNAVAILABLE','synthetic_desoto_cases':len(rows),'oem_pvwatts_approximation_cases':len(oem),'scalar_checks':len(checks),'oem_desoto_computation':'BLOCKED; coefficients unknown','field_validation':'NOT_PERFORMED'}
 (out/'validation_execution_summary.json').write_text(json.dumps(environment,indent=2));print(json.dumps(environment,indent=2))
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--output-dir',default='build/research_reference');parser.add_argument('--source-root');a=parser.parse_args();main(a.output_dir,a.source_root)
