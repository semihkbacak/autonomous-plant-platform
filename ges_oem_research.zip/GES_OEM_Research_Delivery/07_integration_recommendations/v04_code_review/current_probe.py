import os,sys,json
from pathlib import Path
from dataclasses import replace
p=Path(__file__).resolve().parent;sys.path.insert(0,os.environ.get('GES_PROJECT_ROOT',str(p/'source')))
from demo_ges_integrated_v04 import build_integrated_demo_pipeline
from simulator.solar.ges_integrated import IntegratedSolarPhysicsPipeline
from simulator.solar.solar_timeseries import SolarTimeSeriesSimulator
from simulator.solar.solar_stress import make_stress_intervals
base=build_integrated_demo_pipeline();conf={k:replace(v,limits=replace(v.limits,max_operating_a=1.0)) for k,v in base.mppt_configs.items()}
pipe=IntegratedSolarPhysicsPipeline(base.site,base.assets,conf);sim=SolarTimeSeriesSimulator(pipe)
found=None
for x in make_stress_intervals(1):
 r=sim.step(x)
 for report in r.mppt_reports:
  for ch in report.dc.channels:
   if ch.accepted_kw>0 and ch.accepted_kw<ch.offered_kw-1e-6:
    found={'inverter_id':report.inverter_id,'channel':ch.channel,'vmp_v':ch.voltage_v,'imp_a':ch.current_a,'offered_kw':ch.offered_kw,'accepted_kw':ch.accepted_kw,'vmp_times_imp_kw':ch.voltage_v*ch.current_a/1000,'configured_operating_limit_a':1,'reasons':ch.reasons};break
  if found:break
 if found:break
(p/'current_limit_probe.json').write_text(json.dumps(found,indent=2));print(found)
