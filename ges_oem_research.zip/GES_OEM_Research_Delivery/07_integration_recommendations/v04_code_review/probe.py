import os,sys,json,sqlite3,hashlib
from pathlib import Path
from dataclasses import replace,asdict
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,os.environ.get('GES_PROJECT_ROOT',str(ROOT/'source')))
from simulator.solar.component_catalog import Component,ParameterRecord
from simulator.solar.oem_model_readiness import assess_oem_readiness,DESOTO_FIELDS
from demo_ges_integrated_v04 import build_integrated_demo_pipeline,build_integrated_snapshots
from simulator.solar.solar_timeseries import SolarTimeSeriesSimulator,SolarIntervalInput
from simulator.solar.solar_stress import make_stress_intervals
from simulator.solar.historian import SolarHistorian
p=Component('UNVERIFIED_PANEL','panel',{k:ParameterRecord('1','SYNTHETIC','not OEM','') for k in DESOTO_FIELDS})
i=Component('UNVERIFIED_INVERTER','inverter',{k:ParameterRecord('1','SYNTHETIC','not OEM','') for k in ['rated_ac_w','eta_nominal_curve_parameter']})
out={'readiness_accepts_unverified_synthetic_parameters':assess_oem_readiness(p,i).real_physics_ready}
pipe=build_integrated_demo_pipeline(); sim=SolarTimeSeriesSimulator(pipe)
intervals=make_stress_intervals(1)
for x in intervals:sim.step(x)
# Deliberately omit one inverter's MPPT report in a copied record; project remains untouched.
sim.records[0]=replace(sim.records[0],mppt_reports=sim.records[0].mppt_reports[:1])
dbpath=ROOT/'missing_mppt_probe.sqlite3'
if dbpath.exists():dbpath.unlink()
try:
 rid=SolarHistorian(dbpath).save_simulation(sim,scenario='REVIEW_OMITTED_MPPT',inverter_snapshot_payloads=build_integrated_snapshots(pipe))
 with sqlite3.connect(dbpath) as db:
  n=db.execute('select count(distinct inverter_id) from ges_mppt_intervals where run_id=? and start_utc=?',(rid,sim.records[0].start_utc.isoformat())).fetchone()[0]
 out['omitted_mppt_report_persisted_without_rejection']={'accepted':True,'inverters_recorded_first_interval':n,'expected':2}
except Exception as e:out['omitted_mppt_report_persisted_without_rejection']={'accepted':False,'error':str(e)}
manifest=json.loads((ROOT/'source_manifest.json').read_text())
out['source_integrity']={'checked_files':len(manifest),'changed_files':[r['path'] for r in manifest if hashlib.sha256((ROOT/'source'/r['path']).read_bytes()).hexdigest()!=r['sha256']]}
(ROOT/'probe_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps(out,ensure_ascii=False,indent=2))
