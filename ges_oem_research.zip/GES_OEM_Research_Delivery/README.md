# GES OEM Research Delivery

14 Ekim 2026. Yalnız GES araştırması ve entegrasyon önerileri. Mevcut çalışan uygulama, testler ve veritabanları değiştirilmedi; HES ve RES incelenmedi.

Önce `GES_FINAL_TECHNICAL_REPORT.pdf` ve `07_integration_recommendations/ges_technical_inventory.csv` dosyalarını okuyun.

## Sürüm ve erişim sınırı

Önceki paylaşılan Drive bağlantısından 33 GES dosyası yeniden indirildi ve okundu. `oem_model_readiness.py`, `multi_mppt_physics.py`, `ges_integrated.py`, `pq_dispatch.py`, `mppt_history.py` ve `oem_design_review.py` bu klasörde bulunmadı. V0.4, 315 test ve 7 günlük stress bilgileri kullanıcı beyanıdır; bu çalışmada doğrulanmadı. Kaynakta olmayan fonksiyonlara içerik uydurulmadı. `07_integration_recommendations/source_access_manifest.json` erişilen dosyaları ve SHA-256 kaydı kaynak bütünlüğünü gösterir.

## İçerik

| Klasör | Dosyalar / amaç |
|---|---|
| 01_oem_parameter_catalog | Öneri kataloğu, beş kategorili eksik/kanıt listesi, belge çelişkileri |
| 02_panel_desoto_models | Kaynaklı panel CSV, De Soto Excel ve panel PDF, SAM aday araması |
| 03_inverter_efficiency_thermal_pq | İnverter CSV, verim/thermal/PQ Excel, inverter PDF, kaynak örnekleri |
| 04_mppt_string_validation | String Excel, 18 senaryo, 18 fizik açığı CSV ve MPPT PDF |
| 05_independent_validation | 28 genel senaryo, bağımsız kontrol Excel, performans Excel, meteo PDF, script ve sonuçlar |
| 06_manufacturer_sources | Resmi OEM belge bağlantıları, incelenen sayfalar ve URL/revizyon/indirme/SHA-256 kaynak kaydı |
| 07_integration_recommendations | Salt okunur envanter, öneriler, kaynak bütünlüğü ve dosya kalite kontrolleri |

7 Excel ve 5 araştırma PDF'si oluşturuldu. Kaynak OEM belgelerinin resmi bağlantıları06 klasöründedir; tam OEM belgeleri ZIP içine çoğaltılmadı.

## Veri anlamı

- `oem_published`: yalnız seçilen üretici belgesi/revizyonunda yayımlanan değer.
- `derived_from_oem`: yüzde dönüşümü veya alpha_sc gibi matematiksel türetim.
- `graph_digitized_approximate`: grafik okuması; ayrı okuma belirsizliği. İstatistiksel güven aralığı veya cihaz garantisi değildir.
- `model_assumption`: sentetik kontrol girişi veya doğrulanmamış model varsayımı.
- `unknown`: boş alan; sıfır anlamına gelmez.

Katalog mevcut CSV'nin yedi zorunlu kolonunu korur ve izlenebilirlik kolonları ekler. 158 satır, bütün parametrelerin gerçek fizik modelinde desteklendiği anlamına gelmez. Orijinal 76 satırlık CSV değiştirilmedi.

SMA toplam DC akımı120 A açık OEM değeridir. Sungrow110 kVA@45 C ve100 kVA@50 C ankrajları doğrulandı; nominal aktif kW ve tam sıcaklık/P-Q eğrisi tamamlanmadı. Jinko sistem gerilimi1000/1500 V varyantı cihaz etiketiyle seçilmelidir. Seçilen Jinko IV grafiği575 W panel içindir,585 W'e doğrulama diye taşınmadı.

SMA tek parametreli PVWatts uyarlama sonuçları **OEM kullanımına uygun bulunmadı**. Bunlar tanısal araştırma çıktılarıdır; konfigürasyona alınmamalıdır. Gerçek panelin beş De Soto katsayısı boş bırakıldı. İki default fit_desoto denemesi yakınsamadı; hata kayıtları dahil edildi.

## Bağımsız referansları yeniden çalıştırma

Python3.12 ve pvlib0.16.1 ile yapıldı. Bu komutlar yeni bir uygulama yazmaz ve proje kaynaklarına müdahale etmez:

```powershell
py -3.12 -m venv .research-venv
.\.research-venv\Scripts\python.exe -m pip install -r 05_independent_validation/requirements_research.txt
.\.research-venv\Scripts\python.exe 05_independent_validation/ges_independent_reference.py --output-dir build/reference
```

Eriştiğiniz GES kaynak kopyasıyla karşılaştırmak için:

```powershell
.\.research-venv\Scripts\python.exe 05_independent_validation/ges_independent_reference.py --output-dir build/reference --source-root C:/path/to/autonomous-plant-platform
```

Script yalnız GES fizik modüllerini import eder, bytecode yazmayı kapatır ve SQLite bağlantısı açmaz. Kaynak kökü verilmezse APP karşılaştırma kolonları boş kalır; aynı script bağımsız/pvlib sayısal kontrollerini üretir. Güncel v0.4 imzaları farklıysa kaynak karşılaştırması hata verebilir; bu araştırmada erişilmeyen kod için uyum garantisi verilmez.

Gerçekleştirilen kontroller: 16 sentetik De Soto koşulu, 25 skaler/formül kontrolü. Ayrıca32 OEM Pstc/gamma ile yaklaşık PVWatts DC koşulu. Isotropic POA geometrisi karşılaştırması tam Perez-Driesse veya saha doğrulaması değildir. 365 günlük test ve saha doğrulaması yapılmadı. 315 regresyon testini çalıştırdığımız iddia edilmiyor.

## Entegrasyon için gerekli bilgiler

Güncel v0.4 kaynak arşivi/commit, gerçek saha koordinatı/rakımı, MPPT Ns/Np/yönleri, sıcaklık ve Gmax tasarım zarfı, rüzgar yüksekliği/montajı, panel etiketleri/IV ölçümleri, inverter firmware/ülke kodu ve ham verim/thermal/PQ verileri gereklidir. Önce07 bölümündeki öneri/riski inceleyin; katalog veya model çıktısını otomatik gerçek tesis konfigürasyonuna taşımayın.

Google Scholar doğrudan erişilemedi. Literatür DOI/yayıncı özeti, resmi pvlib, Sandia ve üretici belgeleriyle araştırıldı; tam metni alınamayan makaleler kaynak kaydında belirtilmiştir. Windows Excel/Python3.14 çalıştırması yapılmadı; Excel dosyaları Artifact Tool ile hesaplanıp görsel kontrol edildi.

SMA tek-parametreli uyarlamanın reddedilmiş sonuçlarını yeniden üretmek için:

```powershell
.\.research-venv\Scripts\python.exe 05_independent_validation/ges_efficiency_fit_diagnostics.py --output build/efficiency_fit_diagnostics.json
```
