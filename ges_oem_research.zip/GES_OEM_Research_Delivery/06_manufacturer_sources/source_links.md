# Resmi kaynak indeksi

İlgili OEM belgeleri indirildi ve belirtilen sayfaları incelendi. Bu klasör kaynak bağlantılarını, revizyonları ve indirilen belgelerin SHA-256 değerlerini içerir. OEM tam belgeleri ZIP içine çoğaltılmadı; aşağıdaki resmi URL üzerinden edinilebilir.

## L1 - pvlib python: 2023 project update
Revizyon: 2023
URL: https://joss.theoj.org/papers/10.21105/joss.05994
Durum: prior_source_link_retained_not_rechecked
SHA-256: Web kaynağı; PDF hash yok

## L2 - PVWatts Version 5 Manual
Revizyon: 2014
URL: https://doi.org/10.2172/1158421
Durum: prior_source_link_retained_not_rechecked
SHA-256: Web kaynağı; PDF hash yok

## L3 - Improvement and validation of a model for photovoltaic array performance
Revizyon: 2006
URL: https://www.sciencedirect.com/science/article/pii/S0038092X05002410
Durum: publisher_abstract_and_pvlib_method_checked; full_article_not_retrieved
SHA-256: Web kaynağı; PDF hash yok

## L4 - Assessing the outdoor operating temperature of photovoltaic modules
Revizyon: 2008
URL: https://doi.org/10.1002/pip.813
Durum: publisher_abstract_and_Sandia_method_checked; full_article_not_retrieved
SHA-256: Web kaynağı; PDF hash yok

## L5 - Performance Model for Grid-Connected Photovoltaic Inverters
Revizyon: 2007
URL: https://www.sandia.gov/research/publications/details/performance-model-for-grid-connected-photovoltaic-inverters-2007-09-01/
Durum: web_checked
SHA-256: Web kaynağı; PDF hash yok

## L6 - PVWatts V8 API documentation
Revizyon: current
URL: https://developer.nlr.gov/docs/solar/pvwatts/v8/
Durum: prior_source_link_retained_not_rechecked
SHA-256: Web kaynağı; PDF hash yok

## L7 - pvlib.pvsystem.pvwatts_dc
Revizyon: stable inspected 0.16.1; run 0.15.2
URL: https://pvlib-python.readthedocs.io/en/stable/reference/generated/pvlib.pvsystem.pvwatts_dc.html
Durum: prior_source_link_retained_not_rechecked
SHA-256: Web kaynağı; PDF hash yok

## L8 - pvlib.pvsystem.calcparams_desoto
Revizyon: 0.16.1
URL: https://pvlib-python.readthedocs.io/en/v0.16.1/reference/generated/pvlib.pvsystem.calcparams_desoto.html
Durum: web_checked
SHA-256: Web kaynağı; PDF hash yok

## L9 - De Soto Five-Parameter Module Model
Revizyon: current
URL: https://pvpmc.sandia.gov/modeling-guide/2-dc-module-iv/single-diode-equivalent-circuit-models/de-soto-five-parameter-module-model/
Durum: prior_source_link_retained_not_rechecked
SHA-256: Web kaynağı; PDF hash yok

## L10 - pvlib.temperature.faiman
Revizyon: 0.16.1
URL: https://pvlib-python.readthedocs.io/en/v0.16.1/reference/generated/pvlib.temperature.faiman.html
Durum: web_checked
SHA-256: Web kaynağı; PDF hash yok

## L11 - Faiman Module Temperature Model
Revizyon: current
URL: https://pvpmc.sandia.gov/modeling-guide/2-dc-module-iv/module-temperature/faiman-module-temperature-model/
Durum: prior_source_link_retained_not_rechecked
SHA-256: Web kaynağı; PDF hash yok

## L12 - pvlib.inverter.pvwatts
Revizyon: 0.16.1
URL: https://pvlib-python.readthedocs.io/en/v0.16.1/reference/generated/pvlib.inverter.pvwatts.html
Durum: web_checked
SHA-256: Web kaynağı; PDF hash yok

## L13 - pvlib.inverter.sandia
Revizyon: current
URL: https://pvlib-python.readthedocs.io/en/stable/reference/generated/pvlib.inverter.sandia.html
Durum: prior_source_link_retained_not_rechecked
SHA-256: Web kaynağı; PDF hash yok

## L14 - pvlib.ivtools.sdm.fit_desoto
Revizyon: 0.16.1
URL: https://pvlib-python.readthedocs.io/en/v0.16.1/reference/generated/pvlib.ivtools.sdm.fit_desoto.html
Durum: web_checked
SHA-256: Web kaynağı; PDF hash yok

## L15 - pvlib.pvsystem.retrieve_sam
Revizyon: run 0.15.2
URL: https://pvlib-python.readthedocs.io/en/stable/reference/generated/pvlib.pvsystem.retrieve_sam.html
Durum: prior_source_link_retained_not_rechecked
SHA-256: Web kaynağı; PDF hash yok

## L16 - Calculating a module IV curve
Revizyon: current
URL: https://pvlib-python.readthedocs.io/en/stable/gallery/iv-modeling/plot_singlediode.html
Durum: prior_source_link_retained_not_rechecked
SHA-256: Web kaynağı; PDF hash yok

## L17 - pvlib.irradiance.get_total_irradiance
Revizyon: 0.16.1
URL: https://pvlib-python.readthedocs.io/en/v0.16.1/reference/generated/pvlib.irradiance.get_total_irradiance.html
Durum: prior_source_link_retained_not_rechecked
SHA-256: Web kaynağı; PDF hash yok

## D1 - Trina TSM-425 to 445NEG9R.28 EN datasheet
Revizyon: NEG9R.28_EN_2023_A; 2023
URL: https://static.trinasolar.com/sites/default/files/NEG9R.28_EN.pdf
Durum: downloaded
SHA-256: bb1712d2e3656097085c551b6437cda4071b7e38cd8ba0301bc5824070e8b7fd

## D2 - Jinko JKM565-585N-72HL4-(V)-F3-EN datasheet
Revizyon: JKM565-585N-72HL4-(V)-F3-EN; copyright 2022
URL: https://www.jinkosolar.com/uploads/JKM565-585N-72HL4-(V)-F3-EN.pdf
Durum: downloaded
SHA-256: 54dddb4b004da3555b15e24837b876aecddb117e46e9530a96519518ce71ac80

## D3 - SMA STP50-40-DS-en-30 datasheet
Revizyon: STP50-40-DS-en-30; status 02/2020
URL: https://files.sma.de/downloads/STP50-40-DS-en-30.pdf
Durum: downloaded
SHA-256: bcfce44d39ac0e14961a401fdc9753f8621f873c01802edbb7f1b776a2d2b5cd

## D4 - Sungrow SG110CX New datasheet v1.5.2
Revizyon: Version 1.5.2; copyright 2020; URL directory 20221103 is not revision
URL: https://uk.sungrowpower.com/upload/file/20221103/EN%20DS%20SG110CX%20Datasheet.pdf
Durum: downloaded
SHA-256: a9650e3ba847486475aea362f1c0db8dddc2b1a57ce5c69366c8933ec7f0dfdd

## W1 - Using PVGIS 5 / 5.3 datasets
Revizyon: 2024 update
URL: https://joint-research-centre.ec.europa.eu/photovoltaic-geographical-information-system-pvgis/using-pvgis-5_en
Durum: prior_source_link_retained_not_rechecked
SHA-256: Web kaynağı; PDF hash yok

## W2 - PVGIS 5 user manual: timestamps
Revizyon: current
URL: https://joint-research-centre.ec.europa.eu/photovoltaic-geographical-information-system-pvgis/using-pvgis-5/pvgis-5-user-manual_en
Durum: web_checked
SHA-256: Web kaynağı; PDF hash yok

## W3 - PVGIS API non-interactive service
Revizyon: current
URL: https://joint-research-centre.ec.europa.eu/photovoltaic-geographical-information-system-pvgis/using-pvgis-5/api-non-interactive-service_en
Durum: prior_source_link_retained_not_rechecked
SHA-256: Web kaynağı; PDF hash yok

## W4 - PVGIS Hourly radiation output definitions
Revizyon: current
URL: https://joint-research-centre.ec.europa.eu/photovoltaic-geographical-information-system-pvgis/using-pvgis-5/pvgis-5-tools/hourly-radiation_en
Durum: web_checked
SHA-256: Web kaynağı; PDF hash yok

## W5 - Complete ERA5 global atmospheric reanalysis
Revizyon: current
URL: https://www.ecmwf.int/en/forecasts/datasets/complete-era5-global-atmospheric-reanalysis
Durum: official_ECMWF_page_checked
SHA-256: Web kaynağı; PDF hash yok

## W6 - BSRN FAQ
Revizyon: current
URL: https://bsrn.awi.de/faq/
Durum: web_checked
SHA-256: Web kaynağı; PDF hash yok

## W7 - European Commission legal notice
Revizyon: current
URL: https://commission.europa.eu/legal-notice_en
Durum: prior_source_link_retained_not_rechecked
SHA-256: Web kaynağı; PDF hash yok

## D5 - SMA Efficiency and Derating
Revizyon: WirkungDerat-TI-en-52 v5.2
URL: https://files.sma.de/downloads/WirkungDerat-TI-en-52.pdf
Durum: downloaded
SHA-256: f3e078c30187ca5eeba38866487fda58177dbc76e7031cba355f7a53c01c6dd8

## D6 - SMA CORE1 Operating Manual
Revizyon: STP50-4x-BE-en-23 v2.3; 2023-02-14
URL: https://files.sma.de/downloads/STP50-4x-BE-en-23.pdf
Durum: downloaded
SHA-256: 435166ab8ba2883aa4768da6ab0ddd90756c642153fbe6105fedc2196912cd45

## D7 - Sungrow SG110CX User Manual
Revizyon: SG110CX-UEN-Ver18-202106
URL: https://file-support.sungrowpower.com/file/product/SG110CX-UEN-Ver18-202106.pdf
Durum: downloaded
SHA-256: 0e72ae0fa9f11ed9ad8aa7b698f8818bbce2621af3119689f50fcd3d5acf2181

## D8 - SAM CEC Modules library
Revizyon: develop branch retrieved 2026-10-14; row metadata 2026.7.3
URL: https://raw.githubusercontent.com/NREL/SAM/develop/deploy/libraries/CEC%20Modules.csv
Durum: retrieved_or_official_web_checked
SHA-256: a28cf8956a839ed98bb941809b439e4907f5b4c237bd9299bc123fb502c29aff

## D9 - SAM CEC Inverters library
Revizyon: develop branch retrieved 2026-10-14
URL: https://raw.githubusercontent.com/NREL/SAM/develop/deploy/libraries/CEC%20Inverters.csv
Durum: retrieved_or_official_web_checked
SHA-256: 0c1b2188415dad6928f91f1a4c9a820dadc80962549f903d57d9282ba3753760

## M1 - PVsyst Inverter Operating Limits
Revizyon: online; no numbered revision
URL: https://www.pvsyst.com/help-pvsyst7/inverter_operating_limits.htm
Durum: retrieved_or_official_web_checked
SHA-256: Web kaynağı; PDF hash yok

## M2 - Sandia PVPMC Performance Ratio
Revizyon: online; no numbered revision
URL: https://pvpmc.sandia.gov/modeling-guide/5-ac-system-output/pv-performance-metrics/performance-ratio/
Durum: retrieved_or_official_web_checked
SHA-256: Web kaynağı; PDF hash yok

## M3 - PVGIS timestamp bug fix
Revizyon: 2026-03-18
URL: https://joint-research-centre.ec.europa.eu/photovoltaic-geographical-information-system-pvgis/general-information/updates-bug-fixes_en
Durum: retrieved_or_official_web_checked
SHA-256: Web kaynağı; PDF hash yok

## M4 - pvlib calcparams_cec
Revizyon: 0.16.1
URL: https://pvlib-python.readthedocs.io/en/v0.16.1/reference/generated/pvlib.pvsystem.calcparams_cec.html
Durum: retrieved_or_official_web_checked
SHA-256: Web kaynağı; PDF hash yok

## M5 - pvlib fit_cec_sam
Revizyon: 0.16.1
URL: https://pvlib-python.readthedocs.io/en/v0.16.1/reference/generated/pvlib.ivtools.sdm.fit_cec_sam.html
Durum: retrieved_or_official_web_checked
SHA-256: Web kaynağı; PDF hash yok

## M6 - IEC-61853 based PV model validation, Dobos/Freeman
Revizyon: NREL report 68637
URL: https://docs.nrel.gov/docs/fy19osti/68637.pdf
Durum: official_search_abstract_read; full_PDF_download_failed_502
SHA-256: Web kaynağı; PDF hash yok
